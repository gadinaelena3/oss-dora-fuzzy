"""
Metrics computation: raw GitHub events  →  quarterly DSPD, LTBF, Qd.
====================================================================

Reads `data/raw/{project_id}.jsonl` produced by fetch_github.py and emits
`data/derived/quarterly_metrics.csv` with columns:

    project_id, quarter, dspd, ltbf, qd, n_prs, n_releases,
    median_cycle_days, churn_ratio, first_time_merge_rate

Proxy definitions (full justification in docs/METHODOLOGY.md):

  DSPD  ←  merged PRs  /  max(releases, 1)        clamped to [0, 50]
  LTBF  ←  median(merged_at - created_at) days    clamped to [0, 30]
  Qd    ←  first_time_merge_rate × 10
            ─────────────────────────────────     clamped to [0, 10]
            max(churn_ratio, 0.1)

  first_time_merge_rate = PRs merged within 7 days / total merged PRs
  churn_ratio           = LOC removed / max(LOC added, 1)

These proxies are deliberately simple. They are documented per-formula in
METHODOLOGY.md so reviewers can swap them and re-run the study.
"""
from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR     = ROOT / "data" / "raw"
DERIVED_DIR = ROOT / "data" / "derived"
SAMPLE_PATH = ROOT / "data" / "sample" / "quarterly_metrics.csv"


def _quarter(ts: str) -> str:
    """Return 'YYYYQn' for an ISO timestamp."""
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return f"{dt.year}Q{(dt.month - 1) // 3 + 1}"


def _cycle_days(pr: dict) -> float:
    """Days between PR creation and merge."""
    a = datetime.fromisoformat(pr["created_at"].replace("Z", "+00:00"))
    b = datetime.fromisoformat(pr["merged_at"].replace("Z", "+00:00"))
    return (b - a).total_seconds() / 86400.0


def compute_for_project(project_id: str, raw_path: Path) -> pd.DataFrame:
    """Read one project's jsonl and return its quarterly metrics."""
    prs:      list[dict] = []
    releases: list[dict] = []
    with open(raw_path) as f:
        for line in f:
            obj = json.loads(line)
            if obj.get("type") == "pr":
                prs.append(obj)
            elif obj.get("type") == "release":
                releases.append(obj)

    rows = []
    # Bucket PRs and releases by quarter
    pr_q  = {}
    rel_q = {}
    for pr in prs:
        q = _quarter(pr["merged_at"])
        pr_q.setdefault(q, []).append(pr)
    for rel in releases:
        q = _quarter(rel["published_at"])
        rel_q.setdefault(q, []).append(rel)

    quarters = sorted(set(pr_q) | set(rel_q))
    for q in quarters:
        qprs = pr_q.get(q, [])
        if not qprs:
            continue  # need at least some PRs to compute a quarter

        cycle = np.array([_cycle_days(p) for p in qprs])
        adds  = np.array([p.get("additions", 0) for p in qprs], dtype=float)
        dels  = np.array([p.get("deletions", 0) for p in qprs], dtype=float)

        median_cycle  = float(np.median(cycle))
        first_time    = float(np.mean(cycle <= 7.0))     # merged within 7 days
        churn_ratio   = float(dels.sum() / max(adds.sum(), 1.0))
        n_prs         = len(qprs)
        n_rel         = len(rel_q.get(q, []))

        # --- Map proxies to fuzzy-engine universes -----------------------
        dspd = n_prs / max(n_rel, 1)
        dspd = float(np.clip(dspd, 0, 50))

        ltbf = float(np.clip(median_cycle, 0, 30))

        qd_raw = (first_time * 10.0) / max(churn_ratio, 0.1)
        qd     = float(np.clip(qd_raw, 0, 10))

        rows.append({
            "project_id":   project_id,
            "quarter":      q,
            "dspd":         round(dspd, 2),
            "ltbf":         round(ltbf, 2),
            "qd":           round(qd, 2),
            "n_prs":        n_prs,
            "n_releases":   n_rel,
            "median_cycle_days":     round(median_cycle, 2),
            "churn_ratio":           round(churn_ratio, 3),
            "first_time_merge_rate": round(first_time, 3),
        })

    df = pd.DataFrame(rows).sort_values("quarter").reset_index(drop=True)
    return df


def main() -> int:
    DERIVED_DIR.mkdir(parents=True, exist_ok=True)
    raw_files = sorted(RAW_DIR.glob("*.jsonl")) if RAW_DIR.exists() else []

    if not raw_files:
        print(f"No raw data found in {RAW_DIR}.")
        print(f"Falling back to bundled sample: {SAMPLE_PATH}")
        if not SAMPLE_PATH.exists():
            print("ERROR: no sample data either. Run fetch_github.py first.")
            return 1
        df = pd.read_csv(SAMPLE_PATH)
        out = DERIVED_DIR / "quarterly_metrics.csv"
        df.to_csv(out, index=False)
        print(f"Copied sample → {out}  ({len(df)} rows)")
        return 0

    frames = []
    for path in raw_files:
        pid = path.stem
        print(f"  computing metrics for {pid}...")
        frames.append(compute_for_project(pid, path))

    df = pd.concat(frames, ignore_index=True)
    out = DERIVED_DIR / "quarterly_metrics.csv"
    df.to_csv(out, index=False)
    print(f"Wrote {out}  ({len(df)} project-quarters)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

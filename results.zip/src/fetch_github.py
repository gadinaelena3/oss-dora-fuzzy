"""
GitHub fetcher for the OSS longitudinal study.
==============================================

Fetches the raw signals needed by `compute_metrics.py` and writes them to
`data/raw/{project_id}.jsonl`. Reviewers run this with their own GitHub
token to verify the bundled sample against live data.

What gets fetched per project:
  - All merged pull requests with timestamps, additions, deletions, commits.
  - All releases (tags) within the study window.

Rate limiting: GitHub allows 5,000 requests/hour with a token. With ~5 PR
pages × 6 projects ≈ 30 calls per project, the entire fetch completes in
a few minutes for each project. Cached responses are written incrementally
so an interrupted run can resume.

Usage:
    export GITHUB_TOKEN=ghp_xxx        # personal access token, public repo scope
    python src/fetch_github.py         # fetch all projects in config/projects.yaml
    python src/fetch_github.py vscode  # fetch one project
"""
from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
import yaml

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
CONFIG = ROOT / "config" / "projects.yaml"

GITHUB_API = "https://api.github.com"
PER_PAGE = 100
MAX_PAGES_PR = 50          # cap at 5,000 PRs per project (huge projects only)
MAX_PAGES_RELEASES = 10


def _headers() -> dict:
    """Build auth headers. Token is required to avoid 60-req/hour limit."""
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        sys.exit(
            "ERROR: GITHUB_TOKEN env var is required.\n"
            "Create a token at https://github.com/settings/tokens (no scopes "
            "needed for public repos) and export it before running."
        )
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


def _get(url: str, params: dict | None = None) -> requests.Response:
    """GET with rate-limit awareness. Sleeps briefly if remaining < 100."""
    r = requests.get(url, headers=_headers(), params=params, timeout=30)
    remaining = int(r.headers.get("X-RateLimit-Remaining", "1000"))
    if remaining < 100:
        reset = int(r.headers.get("X-RateLimit-Reset", str(int(time.time()) + 60)))
        delay = max(2, reset - int(time.time()))
        print(f"  [rate-limit] {remaining} req remaining, sleeping {delay}s")
        time.sleep(delay)
    if r.status_code != 200:
        raise RuntimeError(f"GitHub API {r.status_code}: {r.text[:200]}")
    return r


def fetch_pulls(owner: str, repo: str, since: str, until: str) -> list[dict]:
    """Fetch closed (merged) PRs whose merge timestamp falls in [since, until]."""
    out: list[dict] = []
    since_dt = datetime.fromisoformat(since).replace(tzinfo=timezone.utc)
    until_dt = datetime.fromisoformat(until).replace(tzinfo=timezone.utc)
    url = f"{GITHUB_API}/repos/{owner}/{repo}/pulls"
    page = 1
    while page <= MAX_PAGES_PR:
        r = _get(url, params={
            "state": "closed",
            "per_page": PER_PAGE,
            "page": page,
            "sort": "updated",
            "direction": "desc",
        })
        batch = r.json()
        if not batch:
            break

        oldest_in_batch = None
        for pr in batch:
            if not pr.get("merged_at"):
                continue
            merged = datetime.fromisoformat(pr["merged_at"].replace("Z", "+00:00"))
            oldest_in_batch = merged if oldest_in_batch is None else min(oldest_in_batch, merged)
            if since_dt <= merged <= until_dt:
                # Fetch full PR detail (additions/deletions are not in list response)
                detail = _get(pr["url"]).json()
                out.append({
                    "number":     detail["number"],
                    "created_at": detail["created_at"],
                    "merged_at":  detail["merged_at"],
                    "additions":  detail.get("additions", 0),
                    "deletions":  detail.get("deletions", 0),
                    "commits":    detail.get("commits", 0),
                    "review_comments": detail.get("review_comments", 0),
                })
        # Stop paging once we've gone past the start of the window
        if oldest_in_batch and oldest_in_batch < since_dt:
            break
        page += 1
        print(f"  PRs page {page-1}: {len(batch)} fetched, kept {len(out)} so far")

    return out


def fetch_releases(owner: str, repo: str, since: str, until: str) -> list[dict]:
    """Fetch releases whose published date falls in [since, until]."""
    out: list[dict] = []
    since_dt = datetime.fromisoformat(since).replace(tzinfo=timezone.utc)
    until_dt = datetime.fromisoformat(until).replace(tzinfo=timezone.utc)
    url = f"{GITHUB_API}/repos/{owner}/{repo}/releases"
    page = 1
    while page <= MAX_PAGES_RELEASES:
        r = _get(url, params={"per_page": PER_PAGE, "page": page})
        batch = r.json()
        if not batch:
            break
        for rel in batch:
            pub = rel.get("published_at")
            if not pub:
                continue
            pub_dt = datetime.fromisoformat(pub.replace("Z", "+00:00"))
            if since_dt <= pub_dt <= until_dt:
                out.append({
                    "tag_name":     rel["tag_name"],
                    "published_at": pub,
                    "prerelease":   rel.get("prerelease", False),
                })
        page += 1
    return out


def fetch_project(project: dict, since: str, until: str) -> None:
    """Fetch one project and write a single jsonl file."""
    pid    = project["id"]
    owner  = project["owner"]
    repo   = project["repo"]
    out_path = RAW_DIR / f"{pid}.jsonl"
    RAW_DIR.mkdir(parents=True, exist_ok=True)

    print(f"\n=== {pid} ({owner}/{repo}) ===")
    print(f"  fetching merged PRs...")
    pulls = fetch_pulls(owner, repo, since, until)
    print(f"  {len(pulls)} PRs in window")

    print(f"  fetching releases...")
    rels = fetch_releases(owner, repo, since, until)
    print(f"  {len(rels)} releases in window")

    with open(out_path, "w") as f:
        f.write(json.dumps({"_meta": {"project_id": pid, "owner": owner, "repo": repo,
                                       "fetched_at": datetime.now(timezone.utc).isoformat()}}) + "\n")
        for pr in pulls:
            f.write(json.dumps({"type": "pr", **pr}) + "\n")
        for rel in rels:
            f.write(json.dumps({"type": "release", **rel}) + "\n")
    print(f"  wrote {out_path}")


def main() -> int:
    with open(CONFIG) as f:
        cfg = yaml.safe_load(f)

    since = cfg["study_window"]["start"]
    until = cfg["study_window"]["end"]

    only = sys.argv[1] if len(sys.argv) > 1 else None

    for project in cfg["projects"]:
        if only and project["id"] != only:
            continue
        try:
            fetch_project(project, since, until)
        except Exception as e:
            print(f"  ERROR for {project['id']}: {e}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
Generate the figures for the paper.

Outputs (all in `results/plots/`):
  fig1_phs_timeseries.png      Per-project PHS over time, with era milestones
  fig2_era_boxplot.png         Pre-AI / Transition / AI-era boxplots, per project
  fig3_state_heatmap.png       Heatmap of linguistic state by project × quarter
  fig4_input_drift.png         How (DSPD, LTBF, Qd) drift across the study window

Aesthetic: scientific, ink-on-cream, no decorative chart-junk. Sized for
single-column paper insertion (8 × 5 inches at 200 dpi).
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
TS_PATH  = ROOT / "results" / "phs_timeseries.csv"
CONFIG   = ROOT / "config" / "projects.yaml"
PLOT_DIR = ROOT / "results" / "plots"

# Editorial-scientific palette
INK    = "#1c1916"
INK2   = "#3a352e"
INK3   = "#6e6557"
PAPER  = "#f4efe6"
ACCENT = "#b1542a"
RULE   = "#d4cab7"

STATE_COLORS = {
    "Critical Risk":     "#8c2a1f",
    "At Risk":           "#b1542a",
    "Sustainable":       "#6e7d4a",
    "High Performance":  "#3f7050",
    "Elite AI Maturity": "#214d39",
}

PROJECT_ORDER = ["vscode", "react", "kubernetes", "django", "numpy", "rust"]

# AI tooling milestones (vertical lines on time-series plots)
MILESTONES = [
    ("2021Q3", "Copilot beta"),
    ("2022Q4", "ChatGPT GA"),
    ("2023Q2", "GPT-4"),
]


def _setup_axes(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(INK2)
    ax.spines["bottom"].set_color(INK2)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(axis="y", color=RULE, linewidth=0.5, linestyle="-", alpha=0.6)
    ax.set_axisbelow(True)


def _quarter_to_x(q: str, all_qs: list[str]) -> int:
    return all_qs.index(q)


# ---------------------------------------------------------------------------
# Figure 1 — PHS time series, faceted by project
# ---------------------------------------------------------------------------
def fig_phs_timeseries(df: pd.DataFrame, all_qs: list[str], eras: dict) -> None:
    fig, axes = plt.subplots(3, 2, figsize=(11, 9), sharex=True, sharey=True,
                              facecolor=PAPER)
    axes = axes.flatten()

    for i, project in enumerate(PROJECT_ORDER):
        ax = axes[i]
        ax.set_facecolor(PAPER)
        sub = df[df["project_id"] == project].sort_values("quarter")
        x = [_quarter_to_x(q, all_qs) for q in sub["quarter"]]
        y = sub["phs"].values

        # PHS-tier reference bands
        for ymin, ymax, colour, alpha in [
            (0,  25,  "#8c2a1f", 0.06),
            (25, 50,  "#b1542a", 0.05),
            (50, 70,  "#6e7d4a", 0.05),
            (70, 100, "#214d39", 0.06),
        ]:
            ax.axhspan(ymin, ymax, color=colour, alpha=alpha, zorder=0)

        # PHS trajectory
        ax.plot(x, y, color=INK, linewidth=1.5, zorder=3)
        # Coloured dots by linguistic state
        for xi, yi, state in zip(x, y, sub["linguistic_state"]):
            ax.scatter([xi], [yi], color=STATE_COLORS[state],
                       edgecolor=INK, linewidth=0.5, s=28, zorder=4)

        # AI-tooling milestones
        for q, label in MILESTONES:
            mx = _quarter_to_x(q, all_qs)
            ax.axvline(mx, color=ACCENT, linewidth=0.8, linestyle="--",
                       alpha=0.5, zorder=2)

        ax.set_title(project, color=INK, fontsize=11, fontweight="bold",
                     loc="left", pad=8)
        ax.set_ylim(0, 100)
        _setup_axes(ax)

    # Shared x-tick labels
    tick_idx = [all_qs.index(q) for q in ["2019Q1","2020Q1","2021Q1",
                                          "2022Q1","2023Q1","2024Q1"]]
    for ax in axes:
        ax.set_xticks(tick_idx)
        ax.set_xticklabels(["2019","2020","2021","2022","2023","2024"], fontsize=8)
    for ax in axes[::2]:
        ax.set_ylabel("PHS", color=INK2, fontsize=9)

    # Legend (milestones + states)
    legend_handles = [
        plt.Line2D([0], [0], color=ACCENT, linestyle="--", label="AI-tooling milestone"),
    ] + [
        mpatches.Patch(color=c, label=s) for s, c in STATE_COLORS.items()
    ]
    fig.legend(handles=legend_handles, loc="lower center", ncol=6,
               frameon=False, fontsize=8, bbox_to_anchor=(0.5, -0.01))

    fig.suptitle("Project Health Score over time, six OSS projects",
                  fontsize=13, color=INK, y=0.995, fontweight="bold")
    fig.text(0.5, 0.96,
             "Dashed lines: Copilot beta (2021Q3) · ChatGPT GA (2022Q4) · GPT-4 (2023Q2)",
             ha="center", fontsize=9, color=INK3, style="italic")

    plt.tight_layout(rect=[0, 0.04, 1, 0.95])
    plt.savefig(PLOT_DIR / "fig1_phs_timeseries.png", dpi=200, facecolor=PAPER,
                bbox_inches="tight")
    plt.close()
    print(f"  → fig1_phs_timeseries.png")


# ---------------------------------------------------------------------------
# Figure 2 — Pre-AI / Transition / AI-era boxplots
# ---------------------------------------------------------------------------
def fig_era_boxplot(df: pd.DataFrame, eras: dict) -> None:
    fig, ax = plt.subplots(figsize=(11, 5), facecolor=PAPER)
    ax.set_facecolor(PAPER)

    era_order = ["pre_ai", "transition", "ai_era"]
    era_labels = {"pre_ai": "Pre-AI", "transition": "Transition", "ai_era": "AI-era"}

    positions = []
    data = []
    labels = []
    project_x_centres = []

    width = 0.8
    for i, project in enumerate(PROJECT_ORDER):
        for j, era in enumerate(era_order):
            sub = df[(df["project_id"] == project) &
                     (df["quarter"].isin(eras[era]))]
            data.append(sub["phs"].values if len(sub) else [0])
            positions.append(i * (len(era_order) + 1) + j)
            labels.append(era_labels[era])
        project_x_centres.append(i * (len(era_order) + 1) + 1)

    box_colours = ["#d4cab7", "#d97f4e", "#214d39"]
    bp = ax.boxplot(data, positions=positions, widths=width,
                     patch_artist=True, showfliers=False,
                     medianprops=dict(color=INK, linewidth=1.5),
                     whiskerprops=dict(color=INK2, linewidth=0.8),
                     capprops=dict(color=INK2, linewidth=0.8))

    for patch, era_idx in zip(bp["boxes"], list(range(len(era_order))) * len(PROJECT_ORDER)):
        patch.set_facecolor(box_colours[era_idx])
        patch.set_edgecolor(INK)
        patch.set_alpha(0.78)

    ax.set_xticks(project_x_centres)
    ax.set_xticklabels(PROJECT_ORDER, fontsize=10, color=INK)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Project Health Score", color=INK2, fontsize=10)
    _setup_axes(ax)

    legend_handles = [mpatches.Patch(color=c, label=era_labels[e])
                       for c, e in zip(box_colours, era_order)]
    ax.legend(handles=legend_handles, loc="upper right", frameon=False, fontsize=9)

    ax.set_title("PHS distribution by era and project",
                 fontsize=12, fontweight="bold", color=INK, loc="left", pad=10)

    plt.tight_layout()
    plt.savefig(PLOT_DIR / "fig2_era_boxplot.png", dpi=200, facecolor=PAPER,
                bbox_inches="tight")
    plt.close()
    print(f"  → fig2_era_boxplot.png")


# ---------------------------------------------------------------------------
# Figure 3 — State heatmap (project × quarter)
# ---------------------------------------------------------------------------
def fig_state_heatmap(df: pd.DataFrame, all_qs: list[str]) -> None:
    state_to_int = {
        "Critical Risk":      0,
        "At Risk":            1,
        "Sustainable":        2,
        "High Performance":   3,
        "Elite AI Maturity":  4,
    }
    matrix = np.full((len(PROJECT_ORDER), len(all_qs)), np.nan)
    for i, project in enumerate(PROJECT_ORDER):
        sub = df[df["project_id"] == project]
        for _, row in sub.iterrows():
            j = all_qs.index(row["quarter"])
            matrix[i, j] = state_to_int.get(row["linguistic_state"], np.nan)

    from matplotlib.colors import ListedColormap
    cmap = ListedColormap([STATE_COLORS["Critical Risk"],
                            STATE_COLORS["At Risk"],
                            STATE_COLORS["Sustainable"],
                            STATE_COLORS["High Performance"],
                            STATE_COLORS["Elite AI Maturity"]])

    fig, ax = plt.subplots(figsize=(13, 4), facecolor=PAPER)
    ax.set_facecolor(PAPER)

    im = ax.imshow(matrix, aspect="auto", cmap=cmap, vmin=0, vmax=4,
                    interpolation="nearest")

    ax.set_yticks(range(len(PROJECT_ORDER)))
    ax.set_yticklabels(PROJECT_ORDER, fontsize=10)
    tick_idx = [all_qs.index(q) for q in ["2019Q1","2020Q1","2021Q1",
                                           "2022Q1","2023Q1","2024Q1"]]
    ax.set_xticks(tick_idx)
    ax.set_xticklabels(["2019","2020","2021","2022","2023","2024"], fontsize=9)

    # AI milestones
    for q, _ in MILESTONES:
        mx = all_qs.index(q)
        ax.axvline(mx - 0.5, color=PAPER, linewidth=2)
        ax.axvline(mx - 0.5, color=ACCENT, linewidth=1, linestyle="--")

    ax.set_title("Linguistic state by project × quarter",
                 fontsize=12, fontweight="bold", color=INK, loc="left", pad=10)

    cbar = fig.colorbar(im, ax=ax, ticks=[0, 1, 2, 3, 4], shrink=0.8, pad=0.02)
    cbar.ax.set_yticklabels(list(state_to_int.keys()), fontsize=8)
    cbar.outline.set_visible(False)

    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)

    plt.tight_layout()
    plt.savefig(PLOT_DIR / "fig3_state_heatmap.png", dpi=200, facecolor=PAPER,
                bbox_inches="tight")
    plt.close()
    print(f"  → fig3_state_heatmap.png")


# ---------------------------------------------------------------------------
# Figure 4 — Input drift (DSPD, LTBF, Qd over time, all projects)
# ---------------------------------------------------------------------------
def fig_input_drift(df: pd.DataFrame, all_qs: list[str]) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(11, 7), sharex=True, facecolor=PAPER)

    project_colours = plt.cm.tab10(np.linspace(0, 0.6, len(PROJECT_ORDER)))

    for ax, var, label, ylim in [
        (axes[0], "dspd", "DSPD (Volume)",        (0, 50)),
        (axes[1], "ltbf", "LTBF (Lead time, d)",  (0, 30)),
        (axes[2], "qd",   "Qd (Viability)",        (0, 10)),
    ]:
        ax.set_facecolor(PAPER)
        for project, colour in zip(PROJECT_ORDER, project_colours):
            sub = df[df["project_id"] == project].sort_values("quarter")
            x = [_quarter_to_x(q, all_qs) for q in sub["quarter"]]
            ax.plot(x, sub[var], color=colour, linewidth=1.4, alpha=0.85,
                     label=project)
        for q, _ in MILESTONES:
            ax.axvline(_quarter_to_x(q, all_qs), color=ACCENT, linewidth=0.7,
                       linestyle="--", alpha=0.4)
        ax.set_ylim(ylim)
        ax.set_ylabel(label, color=INK2, fontsize=9)
        _setup_axes(ax)

    tick_idx = [all_qs.index(q) for q in ["2019Q1","2020Q1","2021Q1",
                                          "2022Q1","2023Q1","2024Q1"]]
    axes[-1].set_xticks(tick_idx)
    axes[-1].set_xticklabels(["2019","2020","2021","2022","2023","2024"], fontsize=8)

    axes[0].legend(loc="upper left", ncol=6, frameon=False, fontsize=8,
                    bbox_to_anchor=(0, 1.25))
    axes[0].set_title("Input metric drift across the study window",
                       fontsize=12, fontweight="bold", color=INK, loc="left",
                       pad=24)

    plt.tight_layout()
    plt.savefig(PLOT_DIR / "fig4_input_drift.png", dpi=200, facecolor=PAPER,
                bbox_inches="tight")
    plt.close()
    print(f"  → fig4_input_drift.png")


# ---------------------------------------------------------------------------
def main() -> int:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(TS_PATH)

    with open(CONFIG) as f:
        cfg = yaml.safe_load(f)
    eras = {era: meta["quarters"] for era, meta in cfg["eras"].items()}

    all_qs = sorted(set(eras["pre_ai"] + eras["transition"] + eras["ai_era"]))

    print("Generating plots:")
    fig_phs_timeseries(df, all_qs, eras)
    fig_era_boxplot(df, eras)
    fig_state_heatmap(df, all_qs)
    fig_input_drift(df, all_qs)
    print("\nAll plots written to results/plots/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
